# lunar

Unified cli for this project.

## Quick start

```bash
uv venv
uv pip install -e .

# run sim + web bridge
lunar sim --world ../gz_worlds/arena1.world --port 8765
```

## Commands

- `lunar sim` - start Gazebo sim + Foxglove bridge
- `lunar doctor` - quick environment checks
- `lunar env` - show effective config + ROS env
- `lunar topics` - run `ros2 topic list`
- `lunar kill` - stop processes started by `lunar sim`
- `lunar config` - show or set config values
