from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from dataclasses import asdict
from enum import Enum

import typer

from .config import Config, CONFIG_PATH, find_repo_root
from .process import spawn, save_state, kill_all

app = typer.Typer(add_completion=False)


class RunProfile(str, Enum):
    ROBOT = "robot"
    RC = "rc"
    AUTONOMY = "autonomy"


def ensure_env(force: bool = False):
    """Ensure the ROS workspace is sourced in the current process."""
    root = find_repo_root()
    setup_script = root / "install" / "setup.bash"
    cfg = Config.load()

    # Apply Domain ID from config
    os.environ["ROS_DOMAIN_ID"] = str(cfg.domain_id)

    # Add Gazebo plugin path
    root = find_repo_root()
    plugin_path = str(root / "src" / "sensor" / "build")
    ros_plugin_path = "/opt/ros/humble/lib"
    current_gz_path = os.environ.get("GAZEBO_PLUGIN_PATH", "")
    
    paths = [plugin_path, ros_plugin_path]
    for p in paths:
        if p not in current_gz_path:
            current_gz_path = f"{p}:{current_gz_path}"
    os.environ["GAZEBO_PLUGIN_PATH"] = current_gz_path

    # If the workspace is already in the path, skip unless forced
    workspace_path = str(root / "install")
    if not force and workspace_path in os.environ.get("COLCON_PREFIX_PATH", ""):
        return

    if setup_script.exists():
        # Capture the environment from a bash subshell
        command = f"source {setup_script} && env"
        proc = subprocess.run(["bash", "-c", command], capture_output=True, text=True)
        for line in proc.stdout.splitlines():
            if "=" in line:
                key, value = line.split("=", 1)
                os.environ[key] = value


@app.callback()
def main():
    """Unified CLI for upmoon25-auto."""
    ensure_env()


@app.command()
def sim(
    world: str = typer.Option(None, "--world", help="The .world file to load. If omitted, defaults to the 'world_path' in lunar config. If the file is not found, you will be prompted to select from gz_worlds/."),
    port: int = typer.Option(None, "--port", help="Custom port for the Foxglove Bridge. Defaults to 8765."),
    headless: bool = typer.Option(False, "--headless", help="Run Gazebo without its heavy Qt GUI. Highly recommended for remote SSH sessions. Uses Xvfb for virtual rendering."),
    autonomy: bool = typer.Option(False, "--autonomy", help="Automatically start the 'main_controller' node immediately after spawning the robot."),
    explain: bool = typer.Option(False, "--explain", help="Display the exact shell commands that would be executed without actually starting them."),
    json_out: bool = typer.Option(False, "--json", help="Output machine-readable status after initialization."),
    no_prompt: bool = typer.Option(False, "--no-prompt", help="Disable interactive prompts. If a world is missing, the command will exit with an error instead of asking for input."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Similar to --explain, but formatted specifically for diagnostic logging."),
    foreground: bool = typer.Option(False, "--foreground", help="Run in the foreground. Streams all process logs (Gazebo, ROS, Spawner) directly to your terminal. Press CTRL-C to stop everything."),
):
    """
    Launch the full Gazebo Simulation Environment.

    This is the primary entry point for simulation. It orchestrates:
    1. Initializing the physics engine (gzserver).
    2. Starting the ROS 2 launch system (robot_state_publisher, transforms).
    3. Spawning the physical robot entity ('my_bot') into the world.
    4. Opening the Foxglove Bridge for 3D visualization.
    """
    cfg = Config.load()
    root = find_repo_root()
    world_path = world or cfg.world_path
    bridge_port = port or cfg.port
    use_headless = headless or cfg.headless
    log_path = root / ".lunar" / "last_sim.log"

    # Auto-cleanup existing processes to ensure a clean start
    typer.echo("Cleaning up existing simulation processes...")
    kill_all()
    subprocess.run(["pkill", "-9", "gzserver"], stderr=subprocess.DEVNULL)
    subprocess.run(["pkill", "-9", "Xvfb"], stderr=subprocess.DEVNULL)
    if Path("/tmp/.X99-lock").exists():
        try: Path("/tmp/.X99-lock").unlink()
        except: pass

    # Handle world file selection
    world_file = Path(world_path).expanduser()
    if not world_file.is_absolute():
        world_file = root / world_path

    if not world_file.exists():
        if no_prompt:
            typer.secho(f"Error: World file not found at {world_file}", fg=typer.colors.RED, err=True)
            raise typer.Exit(code=2)
        
        typer.secho(f"World file not found: {world_path}", fg=typer.colors.YELLOW)
        
        worlds_dir = root / "gz_worlds"
        available_worlds = list(worlds_dir.glob("*.world"))
        
        if available_worlds:
            typer.echo("\nAvailable worlds in gz_worlds/:")
            for i, w in enumerate(available_worlds, 1):
                typer.echo(f" {i}) {w.name}")
            
            choice = typer.prompt("\nSelect a world number or enter a custom path", default="1")
            
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(available_worlds):
                    world_file = available_worlds[idx]
                else:
                    world_file = Path(choice).expanduser()
            except ValueError:
                world_file = Path(choice).expanduser()
        else:
            world_file = Path(typer.prompt("No worlds found in gz_worlds/. Enter path to .world")).expanduser()

    if not world_file.exists():
        typer.secho(f"Error: Final world path does not exist: {world_file}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=2)

    world_path = str(world_file)
    
    gz_cmd = f"gzserver {world_path} -slibgazebo_ros_init.so -slibgazebo_ros_factory.so -slibgazebo_ros_force_system.so -slibgazebo_ros_state.so"
    launch_cmd = f"ros2 launch backend sim_launch.py"
    spawn_cmd = "ros2 run gazebo_ros spawn_entity.py -topic robot_description -entity my_bot -z 0.5 -timeout 60"
    
    if use_headless:
        # Start virtual display if needed
        if not Path("/tmp/.X99-lock").exists():
            subprocess.Popen(["Xvfb", ":99", "-screen", "0", "1280x1024x24"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            time.sleep(1.0)
        os.environ["DISPLAY"] = ":99"

    bridge_cmd = f"{cfg.bridge_cmd} --port {bridge_port}"
    auto_cmd = "ros2 run backend main_controller"

    if dry_run:
        typer.echo(f"gz cmd: {gz_cmd}")
        typer.echo(f"launch cmd: {launch_cmd}")
        return

    # Clear old log
    log_path.parent.mkdir(exist_ok=True)
    log_path.write_text(f"--- Sim started at {time.ctime()} ---\n")

    procs = []
    # 1. Start Gazebo
    procs.append(spawn("gazebo", gz_cmd, log_file=log_path))
    time.sleep(5.0)
    
    # 2. Start Robot State & Autonomy Nodes
    procs.append(spawn("ros_nodes", launch_cmd, log_file=log_path))
    time.sleep(5.0)
    
    # 3. Spawn the actual Robot Entity
    procs.append(spawn("spawner", spawn_cmd, log_file=log_path))
    time.sleep(5.0)

    # 4. Start Bridge
    procs.append(spawn("bridge", bridge_cmd, log_file=log_path))
    
    if autonomy:
        time.sleep(0.5)
        procs.append(spawn("autonomy", auto_cmd, log_file=log_path))

    save_state(procs)

    if not json_out:
        typer.echo(f"Simulation active.")
        typer.echo(f"Foxglove: http://localhost:{bridge_port}")
        typer.echo("Run 'lunar check' to verify status.")

    if not foreground:
        return

    try:
        import selectors
        sel = selectors.DefaultSelector()
        for p in procs:
            if p.proc and p.proc.stdout:
                os.set_blocking(p.proc.stdout.fileno(), False)
                sel.register(p.proc.stdout, selectors.EVENT_READ, p.name)

        while True:
            events = sel.select(timeout=1.0)
            for key, mask in events:
                line = key.fileobj.readline()
                if line:
                    typer.secho(f"[{key.data}] {line.strip()}", dim=True)
    except KeyboardInterrupt:
        typer.echo("\nStopping...")
        kill_all()


@app.command()
def run(
    profile: RunProfile = typer.Argument(..., help="The execution profile to use:\n\n- robot: Launch frontend drivers for physical robot operation.\n- rc: Launch joystick and recording tools for remote control.\n- autonomy: Launch the high-level autonomy stack (mapping, planning)."),
    record: bool = typer.Option(False, "--record", help="Start a rosbag recording of odom and camera data (RC profile only)."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Print the commands that would be run for this profile."),
):
    """
    Execute high-level system profiles for Robot, RC, or Autonomy.

    Profiles are pre-configured sets of ROS 2 nodes tailored for specific tasks.
    They run in the background, and their state is tracked for 'lunar kill'.
    """
    root = find_repo_root()
    log_path = root / ".lunar" / f"run_{profile.value}.log"
    
    cmds = []
    if profile == RunProfile.ROBOT:
        cmds.append(("frontend", "ros2 launch frontend comp_launch.py"))
    
    elif profile == RunProfile.RC:
        cmds.append(("rviz", "rviz2"))
        cmds.append(("joystick", "ros2 run backend joystick_driver"))
        if record:
            cmds.append(("bag", "ros2 bag record /odom /camera /depth /points"))
            
    elif profile == RunProfile.AUTONOMY:
        cmds.append(("rviz", "rviz2"))
        cmds.append(("transport", "ros2 run backend rgb_transport"))
        cmds.append(("controller", "ros2 run backend main_controller"))

    if dry_run:
        for name, cmd in cmds:
            typer.echo(f"[{name}] {cmd}")
        return

    log_path.parent.mkdir(exist_ok=True)
    log_path.write_text(f"--- Profile {profile.value} started at {time.ctime()} ---\n")

    procs = []
    for name, cmd in cmds:
        typer.echo(f"Starting {name}...")
        procs.append(spawn(name, cmd, log_file=log_path))
        time.sleep(0.5)

    save_state(procs)
    typer.echo(f"Profile {profile.value} running in background.")
    typer.echo(f"Logs: {log_path}")
    typer.echo("Run 'lunar kill' to stop.")


@app.command()
def keyboard(
    sim_only: bool = typer.Option(True, "--sim-only/--robot-only", help="Select the target velocity topic. 'sim-only' (default) publishes to /cmd_vel for Gazebo. 'robot-only' publishes to cmd/velocity for the physical hardware abstraction layer."),
):
    """
    Control the robot using your keyboard (Terminal-based).

    This command provides an interactive terminal session for manual driving.
    It uses the standard ROS 2 teleop_twist_keyboard interface but adds
    shortcuts for specific hardware functions.
    \n
    **Movement Controls:**
    - i : Drive Forward
    - k : Stop
    - j/l : Rotate Left / Right
    - u/o : Curve Forward Left / Right
    - m/, : Curve Backward Left / Right
    \n
    **Speed Limits:**
    - q/z : Increase / Decrease max speeds (linear & angular) by 10%
    - w/x : Increase / Decrease linear speed only by 10%
    - e/c : Increase / Decrease angular speed only by 10%
    """
    ensure_env()
    topic = "/cmd_vel" if sim_only else "cmd/velocity"
    typer.secho("\n🎮 KEYBOARD CONTROL", bold=True, fg=typer.colors.CYAN)
    typer.echo(f"Topic: {topic}")
    typer.echo("-" * 20)
    typer.secho("  i : FORWARD", fg=typer.colors.GREEN)
    typer.secho("  k : STOP", fg=typer.colors.RED)
    typer.echo("  j/l : LEFT / RIGHT")
    typer.echo("  u/o : CURVE LEFT / RIGHT")
    typer.echo("  w/x : INCREASE / DECREASE speed limit")
    typer.echo("-" * 20)
    typer.echo("Press 'q' or CTRL-C to exit.\n")
    
    cmd = ["ros2", "run", "teleop_twist_keyboard", "teleop_twist_keyboard", "--ros-args", "--remap", f"cmd_vel:={topic}"]
    try:
        subprocess.run(cmd)
    except KeyboardInterrupt:
        pass


@app.command()
def drive(
    linear: float = typer.Option(1.0, help="Linear velocity in meters per second (m/s). Positive moves forward, negative moves backward."),
    angular: float = typer.Option(0.0, help="Angular velocity in radians per second (rad/s). Positive rotates left, negative rotates right."),
    duration: float = typer.Option(2.0, help="Total time in seconds to continue publishing the velocity command."),
    sim_only: bool = typer.Option(True, "--sim-only/--robot-only", help="Select the target velocity topic. 'sim-only' (default) targets /cmd_vel. 'robot-only' targets cmd/velocity."),
):
    """
    Programmatically drive the robot for a fixed duration.

    This command is designed for non-interactive testing and debugging.
    It publishes a steady stream of geometry_msgs/Twist messages at 10Hz
    for the specified duration. 
    \n
    Example: 'lunar drive --linear 0.5 --duration 5.0' moves the robot 2.5 meters.
    """
    ensure_env()
    topic = "/cmd_vel" if sim_only else "cmd/velocity"
    
    typer.echo(f"Driving: linear={linear}, angular={angular} for {duration}s on {topic}...")
    
    # Calculate number of messages for 10Hz
    rate = 10
    count = int(duration * rate)
    
    cmd = [
        "ros2", "topic", "pub", 
        "--rate", str(rate), 
        "--times", str(count), 
        topic, 
        "geometry_msgs/msg/Twist", 
        f"{{linear: {{x: {linear}, y: 0.0, z: 0.0}}, angular: {{x: 0.0, y: 0.0, z: {angular}}}}}"
    ]
    
    try:
        subprocess.run(cmd)
    except KeyboardInterrupt:
        pass


@app.command()
def lint():
    """
    Run static analysis and linting across the codebase.

    This command uses:
    1. **ty check**: Validates Python type hints and basic syntax.
    2. **ruff check**: A fast, comprehensive linter for PEP8 compliance and bug detection.
    \n
    It scans both the ROS packages in src/ and the lunar CLI source code.
    """
    root = find_repo_root()
    
    typer.secho("--- Running 'ty check' ---", fg=typer.colors.CYAN, bold=True)
    res_ty = subprocess.run(["uvx", "ty", "check"], cwd=str(root))
    
    typer.echo("")
    
    typer.secho("--- Running 'ruff check' ---", fg=typer.colors.CYAN, bold=True)
    res_ruff = subprocess.run(["uvx", "ruff", "check", "."], cwd=str(root))

    if res_ty.returncode == 0 and res_ruff.returncode == 0:
        typer.secho("\n✨ All lint checks passed!", fg=typer.colors.GREEN, bold=True)
    else:
        typer.secho("\n❌ Linting failed.", fg=typer.colors.RED, bold=True)
        raise typer.Exit(code=1)


@app.command()
def build(
    clean: bool = typer.Option(False, "--clean", help="Remove build, install, and log dirs first"),
):
    root = find_repo_root()
    if clean:
        typer.echo("Stopping simulation processes...")
        kill_all()
        # Clean specific non-python processes
        subprocess.run(["pkill", "-9", "gzserver"], stderr=subprocess.DEVNULL)
        subprocess.run(["pkill", "-9", "Xvfb"], stderr=subprocess.DEVNULL)
        subprocess.run(["bash", "-c", "source /opt/ros/humble/setup.bash && ros2 daemon stop"], stderr=subprocess.DEVNULL)
        
        if Path("/tmp/.X99-lock").exists():
            try: Path("/tmp/.X99-lock").unlink()
            except: pass
        
        typer.echo("Cleaning stale build...")
        for d in ["build", "install", "log"]:
            path = root / d
            if path.exists():
                shutil.rmtree(path)
    
    typer.echo("Building upmoon25-auto packages...")
    for pkgs in [["interfaces"], ["frontend", "backend"]]:
        cmd = ["colcon", "build", "--packages-select"] + pkgs
        res = subprocess.run(cmd, cwd=str(root))
        if res.returncode != 0:
            typer.echo(f"Error building packages: {pkgs}")
            raise typer.Exit(code=1)

    typer.echo("Checking for Gazebo (Simulation) components...")
    has_gazebo = bool(shutil.which("gz") or shutil.which("gazebo"))
    
    if not has_gazebo:
        typer.secho("Gazebo not found. Skipping plugin build (Normal for physical robot operation).", fg=typer.colors.YELLOW)
    else:
        typer.echo("Building gazebo plugins...")
        sensor_dir = root / "src" / "sensor"
        build_dir = sensor_dir / "build"
        if build_dir.exists():
            shutil.rmtree(build_dir)
        build_dir.mkdir()
        try:
            subprocess.run(["cmake", ".."], cwd=str(build_dir), check=True)
            subprocess.run(["make"], cwd=str(build_dir), check=True)
        except subprocess.CalledProcessError as e:
            typer.echo(f"Error building gazebo plugins: {e}")
            raise typer.Exit(code=1)

    typer.echo("Updating environment...")
    ensure_env(force=True)
    typer.echo("Build complete!")


@app.command()
def check(
    live: bool = typer.Option(False, "--live", help="Enable live monitoring mode. Instead of a one-time audit, this stays open and streams high-priority logs (WARN and above) from /rosout directly to your terminal."),
    json_out: bool = typer.Option(False, "--json", help="Emit the full audit results as a machine-readable JSON object. Useful for integration with other tools or automated health monitoring."),
):
    """
    Perform a Deep System Audit of the entire Robot & Simulation stack.

    This command executes a comprehensive diagnostic check across multiple layers:
    \n
    1. **Environment:** Verifies ROS 2 Humble installation, Gazebo Classic availability, and Xvfb (virtual display) status.
    \n
    2. **Process Management:** Checks if core background processes (gzserver, foxglove_bridge, Xvfb) are physically running.
    \n
    3. **Gazebo Physics:** Queries the simulation engine to list all active models. Confirms if the robot entity ('my_bot') has successfully spawned.
    \n
    4. **Telemetry Heartbeat:** Samples the ROS 2 topic graph to ensure active data flow for Odometry (/odom) and Joint States (/joint_states).
    \n
    5. **Pose Verification:** Extracts the robot's real-time X, Y, Z coordinates from the physics engine.
    \n
    6. **Coordinate Tree (TF):** Validates the connectivity of the transformation tree (map -> odom -> base_link).
    \n
    7. **Log Analysis:** Scans the last simulation log for critical ERRORS or process deaths to help identify silent failures.
    """
    ensure_env()
    root = find_repo_root()
    log_path = root / ".lunar" / "last_sim.log"
    
    results = {
        "env": {"ros2": bool(shutil.which("ros2")), "gazebo": bool(shutil.which("gz") or shutil.which("gazebo")), "xvfb": bool(shutil.which("Xvfb"))},
        "system_health": {
            "cpu_temp": "N/A",
            "mem_usage": "N/A",
            "disk_free": "N/A",
            "throttled": "Unknown"
        },
        "processes": {},
        "nodes": [],
        "models": [],
        "telemetry": {"odom": False, "joint_states": False, "pos": {"x": 0.0, "y": 0.0, "z": 0.0}},
        "tf_tree": {"map_found": False, "odom_found": False, "base_link_found": False, "wheels_found": False},
        "recent_errors": []
    }

    # --- Real-time System Probes (EE Focus) ---
    import psutil
    results["system_health"]["mem_usage"] = f"{psutil.virtual_memory().percent}%"
    results["system_health"]["disk_free"] = f"{psutil.disk_usage('/').percent}% usage"
    
    # Try to get SoC temperature (Jetson/Linux specific)
    try:
        temp_files = [
            "/sys/class/thermal/thermal_zone0/temp", # CPU
            "/sys/class/thermal/thermal_zone1/temp"  # GPU/SoC
        ]
        temps = []
        for tf in temp_files:
            if Path(tf).exists():
                t = int(Path(tf).read_text().strip()) / 1000.0
                temps.append(f"{t:.1f}C")
        if temps:
            results["system_health"]["cpu_temp"] = " / ".join(temps)
    except: pass

    import concurrent.futures
    try:
        import tomli
    except ImportError:
        tomli = None

    def run_cmd(cmd, timeout=2.0):
        try:
            return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout).stdout
        except:
            return ""

    # --- Hardware Checks ---
    hw_report = []
    if tomli is None:
         hw_report.append({"name": "TOML Support", "path": "tomli", "status": "MISSING (Pip install failed?)"})
    else:
        hw_config_path = root / "lunar" / "hardware.toml"
        if not hw_config_path.exists():
             hw_report.append({"name": "Config File", "path": str(hw_config_path), "status": "MISSING"})
        else:
            with open(hw_config_path, "rb") as f:
                hw_data = tomli.load(f)
            
            # --- New Data-Driven Peripheral Check ---
            # Vision Sensors
            if "vision" in hw_data:
                for v_name, v_cfg in hw_data["vision"].items():
                    model = v_cfg.get("model", v_name)
                    lib = v_cfg.get("driver_lib")
                    found = False
                    if lib:
                         try:
                             found = importlib.util.find_spec(lib) is not None
                         except: found = False
                    
                    status = "READY" if found else "MISSING"
                    # Format: [Category] Logical: Physical
                    display_name = f"[Vision] {v_name}: {model}"
                    hw_report.append({"name": display_name, "status": status, "details": v_cfg})

            # Actuators & Mechanisms
            if "actuation" in hw_data:
                # Drive Train (Nested)
                if "drive_train" in hw_data["actuation"]:
                    dt = hw_data["actuation"]["drive_train"]
                    ctrl = dt.get("controller", "Sabertooth")
                    
                    # Extract parent config (shared props)
                    parent_cfg = {k: v for k, v in dt.items() if not isinstance(v, dict)}

                    for side in ["left", "right"]:
                        if side in dt:
                            dev = dt[side].get("primary_device_path")
                            exists = Path(dev).exists() if dev else False
                            status = "CONNECTED" if exists else "MISSING"
                            
                            # Merge details
                            details = parent_cfg.copy()
                            details.update(dt[side])

                            display_name = f"[Actuation] drive_train ({side}): {ctrl}"
                            hw_report.append({"name": display_name, "status": status, "details": details})
                
                # Mining Mechanism
                if "mining_mechanism" in hw_data["actuation"]:
                    mm = hw_data["actuation"]["mining_mechanism"]
                    on_jetson = Path("/etc/nv_tegra_release").exists()
                    for part in ["spin", "linear"]:
                        if part in mm:
                            cfg = mm[part]
                            ctrl = cfg.get("controller", f"Mining {part}")
                            dev = cfg.get("device_path")
                            if part == "linear":
                                status = "GPIO" if on_jetson else "MISSING"
                                dev = "Internal"
                            else:
                                exists = Path(dev).exists() if dev else False
                                status = "CONNECTED" if exists else "MISSING"
                            display_name = f"[Actuation] mining ({part}): {ctrl}"
                            hw_report.append({"name": display_name, "status": status, "details": cfg})

            # Microcontrollers
            if "microcontrollers" in hw_data:
                for mc_name, mc_cfg in hw_data["microcontrollers"].items():
                    model = mc_cfg.get("model", mc_name)
                    dev = mc_cfg.get("device_path")
                    exists = Path(dev).exists() if dev else False
                    status = "CONNECTED" if exists else "MISSING"
                    display_name = f"[MCU] {mc_name}: {model}"
                    hw_report.append({"name": display_name, "status": status, "details": mc_cfg})
            
            # Check Python Dependencies
            if "system" in hw_data and "python_dependencies" in hw_data["system"]:
                import importlib.util
                for lib, desc in hw_data["system"]["python_dependencies"].items():
                    # Handle mapping from toml key to actual import name if needed (e.g. opencv_python -> cv2)
                    import_name = lib
                    if lib == "opencv_python": import_name = "cv2"
                    if lib == "Jetson_GPIO": import_name = "Jetson.GPIO"
                    
                    try:
                        found = importlib.util.find_spec(import_name) is not None
                    except (ImportError, ModuleNotFoundError):
                        found = False
                        
                    status = "INSTALLED" if found else "MISSING"
                    hw_report.append({
                        "name": f"Lib: {lib}", 
                        "status": status, 
                        "details": {"description": desc, "import_path": import_name}
                    })

    # Map of diagnostic functions to run in parallel
    diag_cmds = {
        "nodes": (["ros2", "node", "list"], 2.0),
        "models": (["ros2", "service", "call", "/get_model_list", "gazebo_msgs/srv/GetModelList", "{}"], 3.0),
        "odom": (["ros2", "topic", "echo", "/odom", "--once"], 2.0),
        "js": (["ros2", "topic", "echo", "/joint_states", "--once"], 2.0),
        "tf": (["ros2", "topic", "echo", "/tf", "--once"], 2.0),
    }

    sim_running = subprocess.run(["pgrep", "gzserver"], capture_output=True).returncode == 0

    if sim_running:
        with concurrent.futures.ThreadPoolExecutor() as executor:
            future_to_diag = {executor.submit(run_cmd, cmd, timeout): key for key, (cmd, timeout) in diag_cmds.items()}
            
            # Collect process statuses while ROS calls are pending
            for proc_name in ["gzserver", "foxglove_bridge", "Xvfb"]:
                is_running = subprocess.run(["pgrep", proc_name], capture_output=True).returncode == 0
                results["processes"][proc_name] = is_running

            # Process results as they come in
            for future in concurrent.futures.as_completed(future_to_diag):
                key = future_to_diag[future]
                out = future.result()
                
                if key == "nodes":
                    results["nodes"] = [n for n in out.splitlines() if n.strip()]
                elif key == "models":
                    if "model_names" in out:
                        import re
                        models = re.findall(r"'(.*?)'", out)
                        results["models"] = [m for m in models if m not in ('', ' ')]
                elif key == "odom":
                    if "position:" in out:
                        results["telemetry"]["odom"] = True
                        import re
                        x = re.search(r"x:\s*([-+]?\d*\.\d+|\d+)", out)
                        y = re.search(r"y:\s*([-+]?\d*\.\d+|\d+)", out)
                        z = re.search(r"z:\s*([-+]?\d*\.\d+|\d+)", out)
                        if x and y and z:
                            results["telemetry"]["pos"] = {"x": float(x.group(1)), "y": float(y.group(1)), "z": float(z.group(1))}
                elif key == "js":
                    results["telemetry"]["joint_states"] = "name:" in out
                elif key == "tf":
                    # Check for both dynamic and static frames in the output
                    results["tf_tree"]["odom_found"] = "frame_id: odom" in out or "child_frame_id: odom" in out
                    results["tf_tree"]["base_link_found"] = "base_link" in out
                    # Check if 'wheel_' is in TF or if any node name contains 'static_wheel'
                    wheels_in_nodes = any("static_wheel" in n for n in results["nodes"])
                    results["tf_tree"]["wheels_found"] = "wheel_" in out or wheels_in_nodes
    else:
        for proc_name in ["gzserver", "foxglove_bridge", "Xvfb"]:
            is_running = subprocess.run(["pgrep", proc_name], capture_output=True).returncode == 0
            results["processes"][proc_name] = is_running

    # Final check: cross-reference node list for TF publishers if topic was empty
    node_str = " ".join(results["nodes"])
    if not results["tf_tree"]["map_found"]:
        results["tf_tree"]["map_found"] = "static_transform_publisher" in node_str or "/robot_state_publisher" in results["nodes"]
    
    # If odom pos is non-zero, odom->base_link must be active
    if results["telemetry"]["odom"] and results["telemetry"]["pos"]["z"] != 0:
        results["tf_tree"]["odom_found"] = True
        results["tf_tree"]["base_link_found"] = True

    if log_path.exists():
        with open(log_path, "r") as f:
            lines = f.readlines()
            results["recent_errors"] = [l.strip() for l in lines if "ERROR" in l.upper() or "process has died" in l.upper()][-8:]

    if json_out:
        typer.echo(json.dumps(results, indent=2))
        return

    typer.secho("\n🔍 SYSTEM AUDIT", bold=True, underline=True)
    
    typer.echo("\n[Environment]")
    for k, v in results["env"].items():
        status = typer.style("OK", fg=typer.colors.GREEN) if v else typer.style("MISSING", fg=typer.colors.RED)
        typer.echo(f"  {k.upper():<8}: {status}")

    typer.echo("\n[System Health]")
    sh = results["system_health"]
    typer.echo(f"  SoC TEMP: {sh['cpu_temp']:<16} MEMORY: {sh['mem_usage']:<16} DISK: {sh['disk_free']}")

    typer.echo("\n[Processes]")
    for k, v in results["processes"].items():
        status = typer.style("RUNNING", fg=typer.colors.GREEN) if v else typer.style("STOPPED", fg=typer.colors.RED)
        typer.echo(f"  {k:<16}: {status}")

    if hw_report:
        typer.echo("\n[Hardware]")
        on_jetson = Path("/etc/nv_tegra_release").exists()
        for item in hw_report:
            s = item["status"]
            color = typer.colors.GREEN if s in ["CONNECTED", "INSTALLED", "READY", "GPIO"] else typer.colors.YELLOW
            
            # Label as missing ONLY if we are missing hardware AND not on a Jetson
            if s == "MISSING" and not on_jetson:
                 s = typer.style("MISSING", fg=typer.colors.BRIGHT_BLACK) + " (Not a Jetson)"
            elif s == "MISSING" and on_jetson:
                 s = typer.style("MISSING", fg=typer.colors.RED, bold=True)
            else:
                 s = typer.style(s, fg=color)
            
            typer.echo(f"  {item['name']:<60}: {s}")
            
            if "details" in item and item["details"]:
                for k, v in item["details"].items():
                    # Handle nested dicts (like identification in arduino) simple flatten for display
                    if isinstance(v, dict):
                         typer.secho(f"    - {k:<25}:", fg=typer.colors.BRIGHT_BLACK)
                         for sub_k, sub_v in v.items():
                             typer.secho(f"      . {sub_k:<23}: {sub_v}", fg=typer.colors.BRIGHT_BLACK)
                    else:
                        typer.secho(f"    - {k:<25}: {v}", fg=typer.colors.BRIGHT_BLACK)

    if not sim_running:
        typer.secho("\n[Simulation internal checks skipped: gzserver is not running]", fg=typer.colors.BRIGHT_BLACK)
        return

    typer.echo("\n[Gazebo Physics]")
    if results["models"]:
        typer.echo(f"  Models: {', '.join(results['models'])}")
        if "my_bot" in results["models"]:
            typer.secho("  ENTITY 'my_bot': SPAWNED", fg=typer.colors.GREEN)
        else:
            typer.secho("  ENTITY 'my_bot': MISSING", fg=typer.colors.RED)
    else:
        typer.secho("  No models found (Check Gazebo/Bridge connectivity)", fg=typer.colors.YELLOW)

    typer.echo("\n[Telemetry Heartbeat]")
    for k in ["odom", "joint_states"]:
        v = results["telemetry"][k]
        status = typer.style("ACTIVE", fg=typer.colors.GREEN) if v else typer.style("STALE/EMPTY", fg=typer.colors.RED)
        typer.echo(f"  {k.upper():<12}: {status}")
    
    if results["telemetry"]["odom"]:
        pos = results["telemetry"]["pos"]
        typer.echo(f"  Current Pose: x={pos['x']:.2f}, y={pos['y']:.2f}, z={pos['z']:.2f}")

    typer.echo("\n[ROS 2 Nodes]")
    typer.echo(f"  Active Count: {len(results['nodes'])}")
    if results["nodes"]:
        if len(results["nodes"]) <= 20:
            for node in results["nodes"]:
                typer.echo(f"    - {node}")
        else:
            for node in results["nodes"][:5]:
                typer.echo(f"    - {node}")
            typer.echo(f"    ... and {len(results['nodes'])-5} more")

    typer.echo("\n[Coordinate Tree (TF)]")
    for frame, found in results["tf_tree"].items():
        status = typer.style("CONNECTED", fg=typer.colors.GREEN) if found else typer.style("DISCONNECTED", fg=typer.colors.RED)
        typer.echo(f"  {frame.replace('_found','').upper():<10}: {status}")

    typer.echo("\n[Recent Errors/Warnings]")
    if results["recent_errors"]:
        for l in results["recent_errors"]:
            color = typer.colors.RED if "ERROR" in l.upper() or "died" in l.upper() else typer.colors.YELLOW
            typer.secho(f"  {l}", fg=color)
    else:
        typer.secho("  No critical errors found in log.", fg=typer.colors.GREEN)

    if live:
        typer.secho("\n--- Live Monitor (Level: WARN+) ---", bold=True, fg=typer.colors.CYAN)
        cmd = ["ros2", "topic", "echo", "/rosout"]
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            while True:
                line = proc.stdout.readline()
                if not line: break
                if any(x in line for x in ["level: 30", "level: 40", "level: 50"]):
                    typer.secho(line.strip(), fg=typer.colors.YELLOW if "30" in line else typer.colors.RED)
        except KeyboardInterrupt:
            proc.terminate()


@app.command()
def logs():
    """
    Follow the simulation logs in real-time.

    This is a convenience wrapper around 'tail -f'. it streams the merged output
    of Gazebo, the ROS 2 launch system, and the robot spawner.
    \n
    Use this to debug:
    - Plugin loading failures
    - URDF/Xacro parsing errors
    - Physics engine crashes
    """
    root = find_repo_root()
    log_path = root / ".lunar" / "last_sim.log"
    if not log_path.exists():
        typer.echo("No log file found.")
        return
    subprocess.run(["tail", "-f", str(log_path)])


@app.command()
def env(
    json_out: bool = typer.Option(False, "--json", help="Emit environment data as JSON."),
):
    """
    Display current CLI configuration and ROS 2 environment variables.

    Shows the active ROS_DOMAIN_ID, the path to the internal lunar config file,
    and all current simulator defaults (headless mode, port, default world).
    """
    cfg = Config.load()
    payload = {
        "config_path": str(CONFIG_PATH),
        "config": asdict(cfg),
        "env": {
            "ROS_DISTRO": os.environ.get("ROS_DISTRO"),
            "ROS_DOMAIN_ID": os.environ.get("ROS_DOMAIN_ID"),
        },
    }
    if json_out:
        typer.echo(json.dumps(payload, indent=2))
        return

    typer.echo(f"config: {CONFIG_PATH}")
    for k, v in asdict(cfg).items():
        typer.echo(f"{k}={v}")
    typer.echo("")
    for k in ["ROS_DISTRO", "ROS_DOMAIN_ID"]:
        if k in os.environ:
            typer.echo(f"{k}={os.environ[k]}")


@app.command()
def topics():
    """
    List all active ROS 2 topics.

    A quick shortcut to 'ros2 topic list' to verify that nodes are communicating.
    """
    cmd = ["ros2", "topic", "list"]
    subprocess.run(cmd, check=False)


@app.command()
def kill():
    """
    Hard-stop all simulation and background processes.

    This is the 'panic button'. It performs the following:
    1. Sends SIGTERM to all process groups tracked in .lunar/state.json.
    2. Force-kills any remaining 'gzserver', 'Xvfb', and ROS nodes.
    3. Stops the ROS 2 daemon.
    """
    msgs = kill_all()
    
    # Aggressive cleanup
    typer.echo("Force-cleaning remaining processes...")
    subprocess.run(["pkill", "-9", "Xvfb"], stderr=subprocess.DEVNULL)
    subprocess.run(["pkill", "-9", "gzserver"], stderr=subprocess.DEVNULL)
    subprocess.run(["pkill", "-9", "streamlit"], stderr=subprocess.DEVNULL)
    subprocess.run(["pkill", "-9", "-f", "ros2"], stderr=subprocess.DEVNULL)
    subprocess.run(["pkill", "-9", "-f", "backend"], stderr=subprocess.DEVNULL)
    subprocess.run(["pkill", "-9", "-f", "frontend"], stderr=subprocess.DEVNULL)
    
    # Stop ROS daemon to clear graph
    subprocess.run(["bash", "-c", "source /opt/ros/humble/setup.bash && ros2 daemon stop"], stderr=subprocess.DEVNULL)

    if Path("/tmp/.X99-lock").exists():
        try: Path("/tmp/.X99-lock").unlink()
        except: pass
    
    if not msgs:
        typer.echo("Cleanup complete.")
        return
    for m in msgs:
        typer.echo(m)


@app.command()
def config(
    set_value: str = typer.Option(
        None,
        "--set",
        help="Update a configuration value. Format: key=value (e.g., --set headless=true)",
    ),
    json_out: bool = typer.Option(False, "--json", help="Emit configuration as JSON."),
):
    """
    View or modify the persistent lunar configuration.

    Available Keys:
    - world_path: Default world file used by 'lunar sim'.
    - port: Port for the Foxglove WebSocket bridge (default: 8765).
    - headless: If true, 'lunar sim' runs without a Gazebo GUI.
    - domain_id: The ROS_DOMAIN_ID (must be 0-101).
    """
    cfg = Config.load()
    if set_value:
        if "=" not in set_value:
            typer.echo("Expected key=value")
            raise typer.Exit(code=1)
        key, value = set_value.split("=", 1)
        key = key.strip()
        value = value.strip()
        if hasattr(cfg, key):
            # Type conversion
            current_val = getattr(cfg, key)
            if isinstance(current_val, bool):
                setattr(cfg, key, value.lower() in {"1", "true", "yes"})
            elif isinstance(current_val, int):
                setattr(cfg, key, int(value))
            else:
                setattr(cfg, key, value)
            cfg.save()
            if json_out:
                typer.echo(cfg.to_json())
            else:
                typer.echo(f"Updated {key}.")
        else:
            typer.echo(f"Unknown key: {key}")
            raise typer.Exit(code=1)
    else:
        typer.echo(cfg.to_json())


@app.command()
def dashboard(
    port: int = typer.Option(8501, help="Port to run the dashboard on."),
    host: str = typer.Option("0.0.0.0", help="Host to bind to."),
    background: bool = typer.Option(True, "--foreground/--background", help="Run the dashboard in the background (default) or foreground."),
):
    """
    Launch the 'Lunar Mission Control' web dashboard.

    This starts a Streamlit server that connects to the ROS 2 network
    and provides real-time telemetry, hardware monitoring, and control.
    """
    root = find_repo_root()
    dashboard_path = root / "lunar" / "src" / "lunar" / "dashboard" / "app.py"
    log_path = root / ".lunar" / "dashboard.log"
    
    if not dashboard_path.exists():
        typer.secho(f"Error: Dashboard app not found at {dashboard_path}", fg=typer.colors.RED)
        raise typer.Exit(1)
        
    typer.secho(f"🚀 Launching Mission Control on http://{host}:{port}", fg=typer.colors.GREEN, bold=True)
    
    # Inject system ROS paths into PYTHONPATH so uv venv can see rclpy
    # ROS 2 Galactic on Jetson (Ubuntu 20.04) strictly uses Python 3.8
    ros_path = f"/opt/ros/galactic/lib/python3.8/site-packages"
    
    cmd = f"export PYTHONPATH=$PYTHONPATH:{ros_path} && source /opt/ros/galactic/setup.bash && streamlit run {dashboard_path} --server.port {port} --server.address {host} --logger.level info"
    
    if background:
        typer.echo("Starting dashboard in background...")
        proc = spawn("dashboard", cmd, log_file=log_path)
        save_state([proc])
        typer.echo(f"Dashboard running in background. Logs: {log_path}")
        typer.echo("Run 'lunar kill' to stop.")
    else:
        try:
            # We use shell=True to allow 'source' and '&&'
            subprocess.run(cmd, shell=True, executable="/bin/bash", check=True)
        except KeyboardInterrupt:
            typer.secho("\nDashboard stopped.", fg=typer.colors.YELLOW)
        except subprocess.CalledProcessError as e:
            typer.secho(f"Streamlit failed with exit code {e.returncode}", fg=typer.colors.RED)


if __name__ == "__main__":
    from dataclasses import asdict
    app()