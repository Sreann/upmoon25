import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry, OccupancyGrid
from sensor_msgs.msg import Image, PointCloud2
from geometry_msgs.msg import PoseStamped, Twist, Vector3
from std_msgs.msg import Int16, String, Float32
from rcl_interfaces.msg import Log
import threading
import time
import psutil
import numpy as np
import subprocess
import os
from lunar.dashboard.state import store

class DashboardBridge(Node):
    def __init__(self):
        super().__init__('lunar_dashboard_bridge')
        
        # Subscribers
        self.create_subscription(Odometry, '/odom', self.odom_cb, 10)
        self.create_subscription(Twist, '/cmd_vel', self.cmd_vel_cb, 10)
        self.create_subscription(Float32, '/sensor/battery', self.battery_cb, 10)
        self.create_subscription(Log, '/rosout', self.log_cb, 10)
        self.create_subscription(Image, '/camera/rgb/image_raw', self.image_cb, 2)
        self.create_subscription(OccupancyGrid, '/map', self.map_cb, 1)
        self.create_subscription(PointCloud2, '/camera/depth/points', self.pc_cb, 1)
        
        # Hardware Topics
        self.create_subscription(Int16, '/sensor/ir/left', self.ir_left_cb, 10)
        self.create_subscription(Int16, '/sensor/ir/right', self.ir_right_cb, 10)
        
        # Publishers
        self.pub_cam_height = self.create_publisher(Int16, '/cmd/camera_height', 10)
        self.pub_bucket = self.create_publisher(Int16, '/cmd/bucket_pos', 10)
        self.pub_goal = self.create_publisher(PoseStamped, '/goal_pose', 10)
        self.pub_macro = self.create_publisher(String, '/cmd/sequence', 10)
        self.pub_pid = self.create_publisher(Vector3, '/cmd/pid_tuning', 10)
        
        # Timer for System Stats (1Hz)
        self.create_timer(1.0, self.system_stats_cb)
        
        self.get_logger().info("Dashboard Bridge Initialized (V2 - Analytics)")

    def odom_cb(self, msg):
        store.update(
            odom_x=msg.pose.pose.position.x,
            odom_y=msg.pose.pose.position.y,
            odom_z=msg.pose.pose.position.z,
            linear_vel=msg.twist.twist.linear.x,
            angular_vel=msg.twist.twist.angular.z
        )

    def cmd_vel_cb(self, msg):
        store.update(baseline_vel=msg.linear.x)

    def battery_cb(self, msg):
        store.update(battery_voltage=msg.data)

    def pc_cb(self, msg):
        store.update(point_cloud_density=msg.width * msg.height)

    def image_cb(self, msg):
        try:
            h, w = msg.height, msg.width
            img = np.frombuffer(msg.data, dtype=np.uint8).reshape((h, w, 3))
            if msg.encoding == "bgr8": img = img[...,::-1]
            store.update(camera_image=img)
        except: pass

    def map_cb(self, msg):
        try:
            w, h = msg.info.width, msg.info.height
            data = np.array(msg.data, dtype=np.int8).reshape((h, w))
            store.update(map_data=data, map_info={"resolution": msg.info.resolution, "origin": (msg.info.origin.position.x, msg.info.origin.position.y)})
        except: pass

    def ir_left_cb(self, msg): store.update(ir_left=msg.data)
    def ir_right_cb(self, msg): store.update(ir_right=msg.data)

    def log_cb(self, msg):
        if msg.level >= 30:
            log_str = f"[{msg.name}] {msg.msg}"
            current_logs = store.get_snapshot().recent_logs
            store.update(recent_logs=(current_logs[-14:] + [log_str]))

    def get_cpu_temp(self):
        try:
            # Linux standard thermal path
            if os.path.exists("/sys/class/thermal/thermal_zone0/temp"):
                with open("/sys/class/thermal/thermal_zone0/temp", "r") as f:
                    return float(f.read()) / 1000.0
            return 0.0
        except: return 0.0

    def system_stats_cb(self):
        cpu = psutil.cpu_percent()
        ram = psutil.virtual_memory().percent
        temp = self.get_cpu_temp()
        
        try:
            res = subprocess.run(["ping", "-c", "1", "-W", "1", "8.8.8.8"], capture_output=True, text=True)
            latency = float(subprocess.re.search(r"time=([\d.]+)", res.stdout).group(1)) if res.returncode == 0 else 0.0
        except: latency = 0.0

        store.update(cpu_usage=cpu, ram_usage=ram, cpu_temp=temp, network_latency=latency)
        
        # Update history
        current = store.get_snapshot()
        with store._lock:
            store._state.history_time.append(time.time())
            store._state.history_cpu.append(cpu)
            store._state.history_vel.append(current.linear_vel)
            store._state.history_base_vel.append(current.baseline_vel)
            store._state.history_latency.append(latency)
            store._state.history_battery.append(current.battery_voltage)
            store._state.history_temp.append(temp)

    def publish_goal(self, x: float, y: float):
        msg = PoseStamped()
        msg.header.stamp, msg.header.frame_id = self.get_clock().now().to_msg(), "map"
        msg.pose.position.x, msg.pose.position.y, msg.pose.orientation.w = x, y, 1.0
        self.pub_goal.publish(msg)

    def trigger_macro(self, name: str): self.pub_macro.publish(String(data=name))
    
    def publish_pid(self, p: float, i: float, d: float):
        msg = Vector3()
        msg.x, msg.y, msg.z = p, i, d
        self.pub_pid.publish(msg)
        store.update(kp=p, ki=i, kd=d)
        self.get_logger().info(f"Published new PID: P={p}, I={i}, D={d}")

    def save_map(self, filename: str): subprocess.Popen(f"ros2 run nav2_map_server map_saver_cli -f /workspace/maps/{filename}", shell=True, executable="/bin/bash")

    def toggle_recording(self, filename: str):
        state = store.get_snapshot()
        if not state.is_recording:
            p = subprocess.Popen(f"ros2 bag record -o /workspace/bags/{filename} /odom /tf /camera/rgb/image_raw /map", shell=True, executable="/bin/bash", preexec_fn=os.setsid)
            store.update(is_recording=True, bag_filename=filename)
            self._bag_proc = p
        else:
            if hasattr(self, '_bag_proc'):
                import signal
                os.killpg(os.getpgid(self._bag_proc.pid), signal.SIGINT)
                store.update(is_recording=False)

    def publish_cam_height(self, value: int):
        self.pub_cam_height.publish(Int16(data=value))
        store.update(camera_height=value)

    def publish_bucket_pos(self, value: int):
        self.pub_bucket.publish(Int16(data=value))
        store.update(bucket_pos=value)

# Global Node Reference
_node = None
_thread = None

def start_ros_thread():
    global _node, _thread
    if _thread is not None and _thread.is_alive(): return
    if not rclpy.ok(): rclpy.init()
    _node = DashboardBridge()
    def spin():
        rclpy.spin(_node)
        rclpy.shutdown()
    _thread = threading.Thread(target=spin, daemon=True)
    _thread.start()

def get_node(): return _node