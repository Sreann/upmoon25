import streamlit as st
import tomli
from pathlib import Path
import importlib.util

def check_hardware_status(root_path: Path):
    hw_report = []
    hw_config_path = root_path / "lunar" / "hardware.toml"
    
    on_jetson = Path("/etc/nv_tegra_release").exists()
    
    if not hw_config_path.exists():
        st.error(f"Config not found at {hw_config_path}")
        return []

    with open(hw_config_path, "rb") as f:
        hw_data = tomli.load(f)

    # --- Reusing Logic from CLI ---
    # Vision Sensors
    if "vision" in hw_data:
        for v_name, v_cfg in hw_data["vision"].items():
            model = v_cfg.get("model", v_name)
            lib = v_cfg.get("driver_lib")
            found = False
            if lib:
                    try:
                        found = importlib.util.find_spec(lib) is not None
                    except: found = False
            
            status = "READY" if found else "MISSING"
            if status == "MISSING" and not on_jetson:
                status = "MISSING (Not a Jetson)"
            hw_report.append({"Category": "Vision", "Name": v_name, "Model": model, "Status": status})

    # Actuators
    if "actuation" in hw_data:
        if "drive_train" in hw_data["actuation"]:
            dt = hw_data["actuation"]["drive_train"]
            ctrl = dt.get("controller", "Sabertooth")
            for side in ["left", "right"]:
                if side in dt:
                    dev = dt[side].get("primary_device_path")
                    exists = Path(dev).exists() if dev else False
                    status = "CONNECTED" if exists else "MISSING"
                    if status == "MISSING" and not on_jetson:
                        status = "MISSING (Not a Jetson)"
                    hw_report.append({"Category": "Actuation", "Name": f"Motor ({side})", "Model": ctrl, "Status": status})

        if "mining_mechanism" in hw_data["actuation"]:
            mm = hw_data["actuation"]["mining_mechanism"]
            for part in ["spin", "linear"]:
                if part in mm:
                    cfg = mm[part]
                    ctrl = cfg.get("controller", f"Mining {part}")
                    dev = cfg.get("device_path")
                    if part == "linear":
                        status = "GPIO" if on_jetson else "MISSING (Not a Jetson)"
                    else:
                        status = "CONNECTED" if Path(dev).exists() else "MISSING"
                        if status == "MISSING" and not on_jetson:
                            status = "MISSING (Not a Jetson)"
                    hw_report.append({"Category": "Actuation", "Name": f"Mining ({part})", "Model": ctrl, "Status": status})

    # Microcontrollers
    if "microcontrollers" in hw_data:
        for mc_name, mc_cfg in hw_data["microcontrollers"].items():
            model = mc_cfg.get("model", mc_name)
            dev = mc_cfg.get("device_path")
            status = "CONNECTED" if Path(dev).exists() else "MISSING"
            hw_report.append({"Category": "MCU", "Name": mc_name, "Model": model, "Status": status})

    return hw_report

def render_hardware_panel(root_path):
    st.subheader("Hardware Inventory")
    
    hw_config_path = root_path / "lunar" / "hardware.toml"
    if not hw_config_path.exists():
        st.error(f"Config not found at {hw_config_path}")
        return

    with open(hw_config_path, "rb") as f:
        hw_data = tomli.load(f)

    # --- Summary Status Table ---
    st.markdown("### Status Summary")
    report = check_hardware_status(root_path)
    if report:
        import pandas as pd
        df = pd.DataFrame(report)
        def color_status(val):
            color = 'red'
            if val in ['READY', 'CONNECTED', 'GPIO']:
                color = 'green'
            return f'color: {color}'
        st.dataframe(df.style.map(color_status, subset=['Status']), use_container_width=True)

    # --- Full Specifications (Entirety of hardware.toml) ---
    st.markdown("### Detailed Specifications")
    
    with st.expander("🔌 Electrical & System Constraints", expanded=True):
        if "electrical_constraints" in hw_data:
            cols = st.columns(len(hw_data["electrical_constraints"]))
            for i, (k, v) in enumerate(hw_data["electrical_constraints"].items()):
                cols[i].metric(k.replace("_", " ").title(), v)
        
    tabs = st.tabs(["Vision", "Sensors", "Actuation", "MCU", "System", "Raw TOML"])
    
    with tabs[0]:
        if "vision" in hw_data:
            for name, cfg in hw_data["vision"].items():
                st.write(f"**{name.replace('_', ' ').title()}**")
                st.json(cfg)

    with tabs[1]:
        if "sensors" in hw_data:
            for name, cfg in hw_data["sensors"].items():
                st.write(f"**{name.replace('_', ' ').title()}**")
                st.json(cfg)

    with tabs[2]:
        if "actuation" in hw_data:
            for name, cfg in hw_data["actuation"].items():
                st.write(f"**{name.replace('_', ' ').title()}**")
                st.json(cfg)

    with tabs[3]:
        if "microcontrollers" in hw_data:
            for name, cfg in hw_data["microcontrollers"].items():
                st.write(f"**{name.replace('_', ' ').title()}**")
                st.json(cfg)

    with tabs[4]:
        if "system" in hw_data:
            st.json(hw_data["system"])

    with tabs[5]:
        st.code(hw_config_path.read_text(), language="toml")
