import streamlit as st
import time
import sys
import numpy as np
import pandas as pd
from pathlib import Path
import plotly.express as px
import plotly.graph_objects as go
import subprocess

# Add project root to sys.path
current_file = Path(__file__).resolve()
project_root = current_file.parents[4] 
if str(project_root) not in sys.path:
    sys.path.append(str(project_root))

from lunar.dashboard.bridge import start_ros_thread, get_node
from lunar.dashboard.state import store
from lunar.dashboard.components.hardware import render_hardware_panel

st.set_page_config(page_title="Lunar Mission Control", page_icon="🌔", layout="wide")

# Initialize bridge only once
if 'ros_bridge' not in st.session_state:
    try:
        from lunar.dashboard.bridge import start_ros_thread
        start_ros_thread()
        st.session_state['ros_bridge'] = True
    except Exception as e:
        st.error(f"Failed to start ROS bridge: {e}")

st.title("🌔 Lunar Mission Control")

state = store.get_snapshot()

# --- Sidebar Configuration ---
with st.sidebar:
    st.header("⚙️ Global Settings")
    with st.expander("🎯 PID Tuning", expanded=False):
        st.write("Target: Drive Controller")
        np_p = st.slider("Kp (Proportional)", 0.0, 10.0, float(state.kp), 0.1)
        ni_i = st.slider("Ki (Integral)", 0.0, 5.0, float(state.ki), 0.01)
        nd_d = st.slider("Kd (Derivative)", 0.0, 5.0, float(state.kd), 0.01)
        if st.button("Apply Gains", use_container_width=True):
            if get_node(): get_node().publish_pid(np_p, ni_i, nd_d)
            st.toast("PID Gains Updated!")
    
    st.divider()
    st.subheader("💻 OS Monitor")
    st.progress(state.cpu_usage / 100.0, text=f"CPU: {state.cpu_usage}%")
    st.progress(state.ram_usage / 100.0, text=f"RAM: {state.ram_usage}%")
    st.metric("CPU Temp", f"{state.cpu_temp:.1f} °C")

tab_cmd, tab_tele, tab_hw, tab_data = st.tabs(["🎮 Command Center", "📊 Analytics & Pulse", "🔍 Hardware", "💾 Data Ops"])

# --- Tab 1: Command Center ---
with tab_cmd:
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Linear Vel", f"{state.linear_vel:.2f} m/s")
    c2.metric("Pos [X, Y]", f"{state.odom_x:.1f}, {state.odom_y:.1f}")
    c3.metric("Battery", f"{state.battery_voltage:.1f} V")
    c4.metric("Latency", f"{state.network_latency:.1f} ms")

    col_vis, col_ctrl = st.columns([2, 1])
    
    with col_vis:
        cv_1, cv_2 = st.columns(2)
        with cv_1:
            st.subheader("👁️ Vision Feed")
            if state.camera_image is not None:
                st.image(state.camera_image, caption="D435 RGB", use_container_width=True)
            else: st.info("Waiting for /camera/rgb/image_raw...")

        with cv_2:
            st.subheader("🗺️ Mapping")
            if state.map_data is not None:
                fig = px.imshow(state.map_data, color_continuous_scale='gray_r', origin='lower')
                fig.update_layout(margin=dict(l=0, r=0, t=0, b=0), height=350)
                st.plotly_chart(fig, use_container_width=True)
            else: st.warning("No Map Data (/map)")

    with col_ctrl:
        st.subheader("🕹️ Controls")
        with st.expander("📍 Waypoints", expanded=True):
            cx, cy = st.columns(2)
            tx, ty = cx.number_input("X", value=0.0), cy.number_input("Y", value=0.0)
            if st.button("🚀 GO TO", use_container_width=True):
                if get_node(): get_node().publish_goal(tx, ty)
        
        st.write("**Macros**")
        m1, m2 = st.columns(2)
        if m1.button("🏁 Home", use_container_width=True):
            if get_node(): get_node().trigger_macro("home")
        if m2.button("⛏️ Dig", use_container_width=True):
            if get_node(): get_node().trigger_macro("dig")

        st.divider()
        st.write("**Manual Override**")
        new_h = st.slider("Cam Height", 0, 100, int(state.camera_height))
        if new_h != state.camera_height:
            if get_node(): get_node().publish_cam_height(new_h)
        new_b = st.slider("Bucket Ext", 0, 100, int(state.bucket_pos))
        if new_b != state.bucket_pos:
            if get_node(): get_node().publish_bucket_pos(new_b)

        st.button("🔴 EMERGENCY STOP", type="primary", use_container_width=True)

# --- Tab 2: Analytics & Pulse ---
with tab_tele:
    col_pulse, col_radar = st.columns([2, 1])
    
    with col_pulse:
        st.subheader("📈 System Vital Trends")
        if len(state.history_time) > 2:
            df_hist = pd.DataFrame({
                "Time": list(state.history_time),
                "CPU Load (%)": list(state.history_cpu),
                "Temp (°C)": list(state.history_temp),
                "Battery (V)": list(state.history_battery)
            })
            df_hist["Time"] -= df_hist["Time"].iloc[0]
            st.line_chart(df_hist, x="Time", y=["CPU Load (%)", "Temp (°C)", "Battery (V)"], height=300)
            
        st.subheader("📉 Odometry Divergence (V-SLAM vs Baseline)")
        if len(state.history_time) > 2:
            df_odom = pd.DataFrame({
                "Time": list(state.history_time),
                "V-SLAM (T265)": list(state.history_vel),
                "Baseline (Cmd)": list(state.history_base_vel)
            })
            df_odom["Time"] -= df_odom["Time"].iloc[0]
            st.line_chart(df_odom, x="Time", y=["V-SLAM (T265)", "Baseline (Cmd)"], height=300)

    with col_radar:
        st.subheader("🦇 IR Proximity Radar")
        fig_radar = go.Figure(go.Scatterpolar(
            r=[state.ir_left, state.ir_right],
            theta=[135, 45],
            mode='markers+lines',
            marker=dict(size=15, color="red"),
            fill='toself',
            name="Proximity"
        ))
        fig_radar.update_layout(
            polar=dict(
                radialaxis=dict(visible=True, range=[0, 1024]),
                angularaxis=dict(tickvals=[0, 45, 90, 135, 180], rotation=90, direction="counterclockwise")
            ),
            showlegend=False,
            height=350,
            margin=dict(l=20, r=20, t=20, b=20)
        )
        st.plotly_chart(fig_radar, use_container_width=True)

# --- Tab 3: Hardware ---
with tab_hw:
    render_hardware_panel(project_root)
    st.divider()
    st.subheader("🛠️ Node Control")
    cs1, cs2, cs3 = st.columns(3)
    if cs1.button("🔄 Restart Mapper"): subprocess.Popen("ros2 node kill /mapper", shell=True)
    if cs2.button("🔄 Restart Controller"): subprocess.Popen("ros2 node kill /motion_controller", shell=True)
    if cs3.button("🔄 Restart Bridge"): subprocess.Popen("ros2 node kill /lunar_dashboard_bridge", shell=True)

# --- Tab 4: Data Operations ---
with tab_data:
    st.subheader("💾 Data Management")
    c_bag, c_map = st.columns(2)
    with c_bag:
        fname = st.text_input("Bag Name", "mission_data")
        if not state.is_recording:
            if st.button("🔴 Start Recording", use_container_width=True):
                if get_node(): get_node().toggle_recording(fname)
        else:
            if st.button("⏹️ Stop Recording", type="primary", use_container_width=True):
                if get_node(): get_node().toggle_recording(fname)
            st.warning(f"Recording: {state.bag_filename}")
    with c_map:
        mname = st.text_input("Map Name", "lunar_v1")
        if st.button("💾 Save Map", use_container_width=True):
            if get_node(): get_node().save_map(mname)
            st.success("Map saving triggered.")

    st.divider()
    st.subheader("📜 System Logs")
    st.code("\n".join(state.recent_logs), language="bash")

# Fast update loop
time.sleep(1.0)
st.rerun()
