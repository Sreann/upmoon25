# Copyright 2016 Open Source Robotics Foundation, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from pysabertooth import Sabertooth
import time
from serial import SerialException

'''
    This node controls the driving of the robot via two Sabertooth motor controllers.
    
    Subscriptions:
    cmd/velocity - Twist, linear.x for forward/backward speed, angular.z for rotation speed
'''
class ReconnectableSaber:
    def __init__(self, logger, port="/dev/ttyUSB0", baudrate=9600, address=128, timeout=0.1, name="Saber"):
        self.logger = logger
        self.port = port
        self.baudrate = baudrate
        self.address = address
        self.timeout = timeout
        self.name = name
        self.saber = None
        self._connect()

    def _connect(self):
        try:
            self.saber = Sabertooth(self.port, baudrate=self.baudrate, address=self.address, timeout=self.timeout)
            self.logger.info(f"[{self.name}] Connected to Sabertooth on {self.port}")
        except Exception as e:
            self.logger.error(f"[{self.name}] Failed to connect on {self.port}: {e}")
            self.saber = None

    def drive(self, motor, speed):
        if not self.saber:
            self._connect()
            if not self.saber:
                return

        try:
            self.saber.drive(motor, speed)
        except SerialException as e:
            self.logger.warn(f"[{self.name}] SerialException on {self.port}: {e}. Reconnecting...")
            self._connect()
        except Exception as e:
            self.logger.error(f"[{self.name}] Unexpected error on {self.port}: {e}")
    
    def stop(self):
        if not self.saber:
            self._connect()
            if not self.saber:
                return

        try:
            self.saber.stop()
        except SerialException as e:
            self.logger.warn(f"[{self.name}] SerialException on {self.port}: {e}. Reconnecting...")
            self._connect()
        except Exception as e:
            self.logger.error(f"[{self.name}] Unexpected error on {self.port}: {e}")


TURN_SPEED = 50.0
DIR = 1.0          # 1 is the correct direction, set to -1 for backwards

class DriveMotors(Node):

    def __init__(self):
        super().__init__('drive_motors')
        
        # Initialize Sabertooths inside the node using the node's logger
        # Mapping based on Jetson udevadm: ACM0 and ACM2 are Sabertooths
        self.saber_l = ReconnectableSaber(self.get_logger(), '/dev/ttyACM0', baudrate=9600, address=128, timeout=0.1, name="Left")
        self.saber_r = ReconnectableSaber(self.get_logger(), '/dev/ttyACM2', baudrate=9600, address=128, timeout=0.1, name="Right")

        self.subscription = self.create_subscription(
            Twist,
            'cmd/velocity',
            self.listener_callback,
            10)
        self.subscription  # prevent unused variable warning
        self.get_logger().info('Successful initialization!')

    def listener_callback(self, msg):
        throttle = msg.linear.x
        rotation = msg.angular.z

        if (throttle != 0.0 and rotation == 0.0):
            self.saber_l.drive(1, throttle*DIR)
            self.saber_l.drive(2, -throttle*DIR)
            self.saber_r.drive(1, throttle*DIR)
            self.saber_r.drive(2, -throttle*DIR)
        elif (throttle != 0.0 and rotation != 0.0):
            t1 = throttle
            t2 = throttle

            if (rotation < 0.0): # left turn
                t2 = int(t2 * 0.5)
            elif (rotation > 0.0): # right turn
                t1 = int(t2 * 0.5)

            self.saber_l.drive(1, t1*DIR)
            self.saber_l.drive(2, -t1*DIR)
            self.saber_r.drive(1, t2*DIR)
            self.saber_r.drive(2, -t2*DIR)
        elif (throttle == 0.0 and rotation != 0.0):
            if (rotation < 0.0): # left turn
                self.saber_r.drive(1, -TURN_SPEED*DIR)
                self.saber_r.drive(2, TURN_SPEED*DIR)
                self.saber_l.drive(1, TURN_SPEED*DIR)
                self.saber_l.drive(2, -TURN_SPEED*DIR)
            elif (rotation > 0.0): # right turn
                self.saber_l.drive(1, -TURN_SPEED*DIR)
                self.saber_l.drive(2, TURN_SPEED*DIR)
                self.saber_r.drive(1, TURN_SPEED*DIR)
                self.saber_r.drive(2, -TURN_SPEED*DIR)
        else:
            self.saber_l.stop()
            self.saber_r.stop()


def main(args=None):
    rclpy.init(args=args)
    drive_motors = DriveMotors()
    try:
        rclpy.spin(drive_motors)
    except KeyboardInterrupt:
        pass
    finally:
        drive_motors.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
