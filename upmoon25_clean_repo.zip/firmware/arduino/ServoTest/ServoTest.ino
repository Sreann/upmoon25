#include <Servo.h>

/*
 * Arduino Firmware for upmoon25-auto
 * 
 * Protocol:
 * Incoming (Serial): "PAN:HGT:BKT
" 
 *   - PAN: 000-180 (Camera Pan)
 *   - HGT: 000-100 (Camera Height Actuator)
 *   - BKT: 000-100 (Bucket Extension Actuator)
 * 
 * Outgoing (Serial): "#IR_R:IR_L
"
 *   - Raw analog values from IR sensors
 */

Servo panServo;
Servo heightServo;
Servo bucketServo;

// Pin Definitions (Adjust based on upmoon25_schematic.pdf if available)
const int PIN_PAN    = 9;
const int PIN_HEIGHT = 10;
const int PIN_BUCKET = 11;
const int PIN_IR_R   = A0;
const int PIN_IR_L   = A1;

void setup() {
  Serial.begin(115200);
  
  panServo.attach(PIN_PAN);
  heightServo.attach(PIN_HEIGHT);
  bucketServo.attach(PIN_BUCKET);
  
  // Initial positions
  panServo.write(90);
  heightServo.write(0);
  bucketServo.write(0);
}

void loop() {
  // 1. Read Commands from ROS 2
  if (Serial.available() >= 12) { // Expecting "000:000:000
" (11 chars + 
)
    String data = Serial.readStringUntil('
');
    if (data.length() >= 11) {
      int pan = data.substring(0, 3).toInt();
      int hgt = data.substring(4, 7).toInt();
      int bkt = data.substring(8, 11).toInt();
      
      panServo.write(constrain(pan, 0, 180));
      
      // Actuators usually take PWM or Servo signals
      // Mapping 0-100 percentage to 0-180 servo degrees
      heightServo.write(map(constrain(hgt, 0, 100), 0, 100, 0, 180));
      bucketServo.write(map(constrain(bkt, 0, 100), 0, 100, 0, 180));
    }
  }

  // 2. Send Sensor Data to ROS 2
  int irR = analogRead(PIN_IR_R);
  int irL = analogRead(PIN_IR_L);
  
  Serial.print("#");
  Serial.print(irR);
  Serial.print(":");
  Serial.println(irL);
  
  delay(10); // ~100Hz update rate
}
